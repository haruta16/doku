extends SceneTree
var checks: int = 0
var failures: int = 0
func _initialize() -> void:
	_run.call_deferred()
func _run() -> void:
	_check(root.get_child_count() == 0, "no product/framework Autoload")
	var player := AudioStreamPlayer.new()
	root.add_child(player)
	player.stream = load("res://dlg_open_1.ogg")
	_check(player.stream is AudioStreamOggVorbis, "same Vorbis asset loads")
	var mode: String = OS.get_cmdline_user_args()[0]
	if mode == "play": player.play()
	for i in 4: await process_frame
	player.stop()
	player.stream = null
	player.free()
	_check(not is_instance_valid(player), "player released before quit")
	print("PURE_AUDIO_EXIT checks=%d failures=%d mode=%s" % [checks, failures, mode])
	quit(0 if failures == 0 else 1)
func _check(value: bool, _message: String) -> void:
	checks += 1
	if not value: failures += 1
