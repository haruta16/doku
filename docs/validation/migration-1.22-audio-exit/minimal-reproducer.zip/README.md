# Immediate Ogg playback exit reproduction

This fixture contains no product or framework scripts and has zero Autoloads.
It uses the exact original dlg_open_1.ogg bytes. Godot 4.6.1 custom build
14d19694e (Darwin arm64) produced: load_only 3/0 strict pass; play 3/0 strict
failure with four Ogg objects and two resources retained at process exit.
The play case intentionally remains a failed strict test. No delay or diagnostic
waiver is added. The internal engine cause and long-running memory behavior are
not established by this comparison.

Extract into a temporary folder, using an isolated Godot executable:

    godot --headless --path <folder> --editor --import
    godot --headless --verbose --path <folder> --script res://probe.gd -- load_only
    godot --headless --verbose --path <folder> --script res://probe.gd -- play

The project uses the dedicated DokuIsolatedValidation user directory identity;
it contains no network/native SDK code, product data, or engine cache. Both cases
wait exactly four process_frame signals, then stop the player, clear its stream,
free the player and quit immediately. Exit code zero alone is not a pass: retain
and classify shutdown diagnostics as recorded in report.json and play.log.
